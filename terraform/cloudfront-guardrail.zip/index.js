const { CloudFrontClient, GetDistributionCommand, UpdateDistributionCommand } = require("@aws-sdk/client-cloudfront");

const client = new CloudFrontClient({});

exports.handler = async () => {
  const distributionId = process.env.DISTRIBUTION_ID;
  if (!distributionId) throw new Error("Missing DISTRIBUTION_ID");

  const cfg = await client.send(new GetDistributionCommand({ Id: distributionId }));
  const dist = cfg.Distribution;
  if (!dist || !dist.DistributionConfig) throw new Error("No distribution config");
  if (dist.DistributionConfig.Enabled === false) {
    console.log("Distribution already disabled");
    return;
  }

  const etag = cfg.ETag;
  const updated = {
    ...dist.DistributionConfig,
    Enabled: false,
  };

  await client.send(
    new UpdateDistributionCommand({
      Id: distributionId,
      IfMatch: etag,
      DistributionConfig: updated,
    })
  );

  console.log("Disabled CloudFront distribution " + distributionId);
};
